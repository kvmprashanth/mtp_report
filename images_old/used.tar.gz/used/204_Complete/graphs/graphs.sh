gnuplot memory_usage

python exceed.py
gnuplot exceed

python gl_cum.py
gnuplot gl_cum

python gl_dist.py
gnuplot gl_dist

python smr_dist.py
gnuplot smr_dist

gnuplot smr_cum

python app_met.py
gnuplot app_met mongo_met redis_met

